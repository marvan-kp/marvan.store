module.exports = {
    PRODUCT_COLLECTION: 'product',
    USER_COLLECTION: 'user',
    CART_COLLECTION: 'cart',
    ORDER_COLLECTION: 'order',
    ADMIN_COLLECTION: 'ADMIN_COLLECTION'
};